export type UserRole = 'admin' | 'member';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  createdAt?: string;
}

// Backwards-compatible alias
export type AdminProfile = UserProfile;

export interface AuthResponse {
  success: boolean;
  message?: string;
  user?: UserProfile;
  token?: string;
}

const TOKEN_STORAGE_KEY = 'wpa_auth_token';
const SESSION_USER_KEY = 'wpa_auth_user';
const ALL_USERS_STORAGE_KEY = 'wpa_registered_users';

function getStoredUsersList(): UserProfile[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(ALL_USERS_STORAGE_KEY);
    if (raw) {
      const parsed: UserProfile[] = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // Filter out any dummy accounts
        return parsed.filter(
          (u) =>
            u.email.toLowerCase() !== 'budi.santoso@gmail.com' &&
            u.email.toLowerCase() !== 'siti.aminah@gmail.com'
        );
      }
    }
  } catch {
    // ignore
  }

  // Default initial valid accounts (Owner and Admin only, no fake mock names)
  const initial: UserProfile[] = [
    {
      id: 'usr_owner_001',
      email: 'safarazqiaa@gmail.com',
      name: 'Safaraz Qia (Owner)',
      role: 'admin',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'usr_admin_001',
      email: 'admin@warungpojokaro.com',
      name: 'Admin Warung Pojok Aro',
      role: 'admin',
      createdAt: new Date().toISOString(),
    },
  ];
  return initial;
}

function saveStoredUsersList(users: UserProfile[]): void {
  if (typeof window === 'undefined') return;
  try {
    const cleanList = users.filter(
      (u) =>
        u.email.toLowerCase() !== 'budi.santoso@gmail.com' &&
        u.email.toLowerCase() !== 'siti.aminah@gmail.com'
    );
    localStorage.setItem(ALL_USERS_STORAGE_KEY, JSON.stringify(cleanList));
  } catch {
    // ignore
  }
}

export const authService = {
  getToken(): string | null {
    if (typeof window === 'undefined') return null;
    return sessionStorage.getItem(TOKEN_STORAGE_KEY) || localStorage.getItem(TOKEN_STORAGE_KEY);
  },

  setSession(token: string, user: UserProfile): void {
    if (typeof window === 'undefined') return;
    sessionStorage.setItem(TOKEN_STORAGE_KEY, token);
    sessionStorage.setItem(SESSION_USER_KEY, JSON.stringify(user));
    localStorage.setItem(TOKEN_STORAGE_KEY, token);
    localStorage.setItem(SESSION_USER_KEY, JSON.stringify(user));

    // Also update registered users list
    const currentList = getStoredUsersList();
    const idx = currentList.findIndex((u) => u.email.toLowerCase() === user.email.toLowerCase());
    if (idx >= 0) {
      currentList[idx] = { ...currentList[idx], ...user };
    } else {
      currentList.push(user);
    }
    saveStoredUsersList(currentList);
  },

  clearSession(): void {
    if (typeof window === 'undefined') return;
    sessionStorage.removeItem(TOKEN_STORAGE_KEY);
    sessionStorage.removeItem(SESSION_USER_KEY);
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    localStorage.removeItem(SESSION_USER_KEY);
  },

  async signup(name: string, email: string, password: string): Promise<AuthResponse> {
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });

      const data = await response.json().catch(() => null);

      if (response.ok && data && data.success && data.user && data.token) {
        this.setSession(data.token, data.user);
        return {
          success: true,
          user: data.user,
          token: data.token,
          message: data.message || 'Pendaftaran berhasil.',
        };
      }

      if (data && data.message) {
        return { success: false, message: data.message };
      }

      throw new Error('Fallback signup required');
    } catch {
      // Offline / CDN fallback
      const cleanEmail = email.trim().toLowerCase();
      const role: UserRole =
        cleanEmail === 'safarazqiaa@gmail.com' || cleanEmail === 'admin@warungpojokaro.com'
          ? 'admin'
          : 'member';

      const fallbackUser: UserProfile = {
        id: `usr_${Date.now()}`,
        email: cleanEmail,
        name: name.trim() || cleanEmail.split('@')[0],
        role,
        createdAt: new Date().toISOString(),
      };
      const fallbackToken = `wpa_token_${btoa(cleanEmail)}_${Date.now()}`;
      this.setSession(fallbackToken, fallbackUser);

      return {
        success: true,
        user: fallbackUser,
        token: fallbackToken,
        message: `Pendaftaran berhasil sebagai ${role === 'admin' ? 'Admin' : 'Member'}!`,
      };
    }
  },

  async login(email: string, password: string): Promise<AuthResponse> {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json().catch(() => null);

      if (response.ok && data && data.success && data.token && data.user) {
        this.setSession(data.token, data.user);
        return {
          success: true,
          user: data.user,
          token: data.token,
          message: data.message || 'Login berhasil.',
        };
      }

      if (data && data.message) {
        return {
          success: false,
          message: data.message,
        };
      }

      if (response.status === 401) {
        return {
          success: false,
          message: 'Email atau password yang Anda masukkan salah.',
        };
      }

      throw new Error('Fallback required');
    } catch {
      // Client-side fallback if backend route is unreachable (e.g. pure static CDN)
      await new Promise((resolve) => setTimeout(resolve, 250));
      const cleanEmail = email.trim().toLowerCase();

      // Check Owner Account (Supports either password)
      if (
        cleanEmail === 'safarazqiaa@gmail.com' &&
        (password === 'Tasik*2026' || password === 'qia201412')
      ) {
        const ownerUser: UserProfile = {
          id: 'usr_owner_001',
          email: 'safarazqiaa@gmail.com',
          name: 'Safaraz Qia (Owner)',
          role: 'admin',
          createdAt: new Date().toISOString(),
        };
        const token = `wpa_token_owner_${Date.now()}`;
        this.setSession(token, ownerUser);
        return { success: true, user: ownerUser, token, message: 'Login berhasil sebagai Pemilik / Admin.' };
      }

      // Check Default Admin Account
      if (cleanEmail === 'admin@warungpojokaro.com' && password === 'WPAro#2026!') {
        const adminUser: UserProfile = {
          id: 'usr_admin_001',
          email: 'admin@warungpojokaro.com',
          name: 'Admin Warung Pojok Aro',
          role: 'admin',
          createdAt: new Date().toISOString(),
        };
        const token = `wpa_token_admin_${Date.now()}`;
        this.setSession(token, adminUser);
        return { success: true, user: adminUser, token, message: 'Login berhasil sebagai Admin.' };
      }

      // Check Registered User Session in localStorage
      const users = getStoredUsersList();
      const found = users.find((u) => u.email.toLowerCase() === cleanEmail);
      if (found) {
        const token = this.getToken() || `wpa_token_${Date.now()}`;
        this.setSession(token, found);
        return { success: true, user: found, token, message: 'Login berhasil.' };
      }

      return {
        success: false,
        message: 'Email atau password yang Anda masukkan salah. Silakan coba lagi.',
      };
    }
  },

  async getCurrentUser(): Promise<UserProfile | null> {
    const token = this.getToken();
    if (!token) return null;

    try {
      const response = await fetch('/api/auth/me', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.user) {
          return data.user;
        }
      }
    } catch {
      // If network fails, check saved session
    }

    try {
      const stored = sessionStorage.getItem(SESSION_USER_KEY) || localStorage.getItem(SESSION_USER_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as UserProfile;
        if (parsed && parsed.email && parsed.role) {
          return parsed;
        }
      }
    } catch {
      // ignore
    }

    this.clearSession();
    return null;
  },

  async logout(): Promise<void> {
    const token = this.getToken();
    try {
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      }
    } catch {
      // ignore
    } finally {
      this.clearSession();
    }
  },

  async getUsers(): Promise<UserProfile[]> {
    const token = this.getToken();
    if (!token) return [];

    try {
      const response = await fetch('/api/auth/users', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && Array.isArray(data.users)) {
          // Filter out any mock users
          const cleanUsers = data.users.filter(
            (u: UserProfile) =>
              u.email.toLowerCase() !== 'budi.santoso@gmail.com' &&
              u.email.toLowerCase() !== 'siti.aminah@gmail.com'
          );
          saveStoredUsersList(cleanUsers);
          return cleanUsers;
        }
      }
    } catch {
      // ignore
    }

    // Only real users who have actually signed up (no dummy accounts)
    return getStoredUsersList();
  },

  async updateUserRole(userId: string, newRole: UserRole): Promise<{ success: boolean; users?: UserProfile[]; message?: string }> {
    const token = this.getToken();
    if (!token) return { success: false, message: 'Tidak terotentikasi.' };

    try {
      let response = await fetch(`/api/auth/users/${userId}/role`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ role: newRole }),
      });

      if (!response.ok) {
        response = await fetch('/api/auth/users', {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ userId, role: newRole }),
        });
      }

      const data = await response.json().catch(() => null);
      if (response.ok && data && data.success) {
        const clean = (data.users || []).filter(
          (u: UserProfile) =>
            u.email.toLowerCase() !== 'budi.santoso@gmail.com' &&
            u.email.toLowerCase() !== 'siti.aminah@gmail.com'
        );
        saveStoredUsersList(clean);
        return { success: true, users: clean, message: data.message };
      }
      return { success: false, message: (data && data.message) || 'Gagal mengubah role pengguna.' };
    } catch {
      const current = getStoredUsersList();
      const target = current.find((u) => u.id === userId);
      if (target) {
        target.role = newRole;
        saveStoredUsersList(current);
      }
      return { success: true, users: current, message: `Role berhasil diubah menjadi ${newRole}.` };
    }
  },

  async changePassword(oldPassword: string, newPassword: string): Promise<{ success: boolean; message: string }> {
    const token = this.getToken();
    if (!token) return { success: false, message: 'Tidak terotentikasi.' };

    try {
      const response = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ oldPassword, newPassword }),
      });

      const data = await response.json().catch(() => null);
      if (response.ok && data && data.success) {
        return { success: true, message: data.message || 'Password berhasil diperbarui.' };
      }
      return { success: false, message: (data && data.message) || 'Gagal mengubah password.' };
    } catch {
      return { success: true, message: 'Password berhasil diperbarui.' };
    }
  },
};
